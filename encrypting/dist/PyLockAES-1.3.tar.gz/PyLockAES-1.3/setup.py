from setuptools import setup

setup(
    name='PyLockAES',
    version='1.3',
    description='A library for encrypting files with AES',
    author='INeddHelp',
    author_email='ineddhelpgithub@gmail.com',
    packages=['pylockaes']
)