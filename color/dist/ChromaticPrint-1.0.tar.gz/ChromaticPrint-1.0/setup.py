from setuptools import setup

setup(
    name='ChromaticPrint',
    version='1.0',
    description='A library for printing colored text in the terminal',
    author='INeddHelp',
    author_email='ineddhelpgithub@gmail.com',
    url='https://github.com/INeddHelp/Colors-python-library',
    packages=['chromaticprint']
)
