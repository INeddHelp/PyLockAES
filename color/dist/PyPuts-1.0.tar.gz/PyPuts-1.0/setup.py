from setuptools import setup

setup(
    name='PyPuts',
    version='1.0',
    description='PyPuts: A Python Library for Colorful and Readable Console Output',
    author='INeddHelp',
    author_email='ineddhelpgithub@gmail.com',
    url='https://github.com/INeddHelp/PyPuts',
    packages=['pyputs']
)
